/**
  * @author       : Amar Kumar 
  * @date         : 08/02/2016
  * @description  : This is a class which will be responsible for :
  *                     1) Creating & deactivating a user and its associated sales consultant.
  *                     2) Navigate to respective pages for creating & deactivating a user and its associated sales consultant.
*/
public with sharing class TestSalesConsultant {

    public String isInstaller { get; set; }
    
    public boolean bOnBoardSC{get;set;}
    public boolean bOffBoardSC{get;set;}
    
    public final User user{get;set;}
    public CKSW_BASE__Resource__c sc;
    public String storeCode{get;set;} // input store code value from OnboardUser page.
    
    public String sm_Name{get;set;}
    
    public List<User> lstUser{get;set;}
    public string LDAP{get;set;}
    
    public String selectedTimeZone{get;set;}
    public String strNewSM_Name{get;set;}
    public String strBranch{get;set;}
    
    // HDI
    public boolean skills_Cabinet{get;set;}  // input skills_Cabinet value from OnboardUser page.
    public boolean skills_Closet{get;set;}   // input skills_Closet value from OnboardUser page.
    public boolean skills_Garage{get;set;}   // input skills_Garage value from OnboardUser page.
    public boolean skills_Bath{get;set;}     // input skills_Bath value from OnboardUser page.

    // HDE
    public boolean skills_Gutters{get;set;}         // input skills_Gutters value from OnboardUser page.
    public boolean skills_Insulation{get;set;}      // input skills_Insulation value from OnboardUser page.
    public boolean skills_Roofing{get;set;}         // input skills_Roofing value from OnboardUser page.
    public boolean skills_Siding{get;set;}          // input skills_Siding value from OnboardUser page.
    public boolean skills_StormProtection{get;set;} // input skills_StormProtection value from OnboardUser page.
    public boolean skills_Windows{get;set;}         // input skills_Windows value from OnboardUser page.
    
    /**
      * @description       Default constructor of ManageSalesConsultant.
      * @param             N/A
      * @return            N/A
      * @throws            N/A
    */
    public TestSalesConsultant(){
        user = new USER();
        lstUser = new List<User>();
    } 

    /**
      * @description       This method is will be called when user clicks on previous button from 'OnboardUser' page. Once clicked, User will be redirected to 'ManageSalesConsultant' page.                          
      * @param             N/A
      * @return            PageReference
      * @throws            N/A
    */ 
    public PageReference PreviousSC() {
        PageReference pageRef = new PageReference('/apex/TestSCOnboard');
        pageRef.setRedirect(true);
        return pageRef;
    }
    
    /**
      * @description       This method is will be called to create USER & its associated Sales Consultant records.                          
      * @param             N/A
      * @return            pageReference
      * @throws            N/A
    */
    
    public PageReference createSC(){
        boolean isUserExist = false;
        boolean isManagerExist = false;
        boolean isStoreExist = false;
        boolean isRepNumberExist = false;
        boolean isValidationErrorOccured = false;
        String strSM_Id = null;
        
        if(bOnBoardSC == null){
            Pagereference pf = new PageReference('/apex/TestSCOnboard');
            pf.setRedirect(true);
            return pf;
        }
        if(String.IsNotBlank(user.Email) && user.Email.Length() > 80){
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Email should be less then 80 characters.'));
            isValidationErrorOccured = true;
        }
        if(String.IsNotBlank(user.Email) && (!user.Email.endsWith('@homedepot.com'))){
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Email should be of HomeDepot domain.'));
            isValidationErrorOccured = true;
        }
        if(String.IsNotBlank(user.Associate_Code__c)){
            if(user.Associate_Code__c.length() > 10){
                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'User LDAP should be not be more than 10 characters.'));
                isValidationErrorOccured = true;
            }
            else{
                boolean flag = validateAlphaNumeric(user.Associate_Code__c);
                if(!flag){
                    ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'User LDAP should contain only alphanumeric characters.'));
                    isValidationErrorOccured = true;
                }
            }
        }
        if(String.IsNotBlank(storeCode) && storeCode.length() != 4){
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Store code should be 4 characters.'));
            isValidationErrorOccured = true;
        }
        if(String.IsNotBlank(user.Repnum__c) ){
            if(user.Repnum__c.length() > 10 ){
                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Rep Number should be 10 characters or less.'));
                isValidationErrorOccured = true;
            }
            else{
                boolean flag = validateAlphaNumeric(user.Repnum__c);
                if(!flag){
                    ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Rep Number should contain only alphanumeric characters.'));
                    isValidationErrorOccured = true;
                }
            }
        }
        if(String.IsNotBlank(user.FirstName) && user.FirstName.length() > 40){
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'First name should be should be 40 characters or less.'));
            isValidationErrorOccured = true;
        }
        if(String.IsNotBlank(user.LastName) && user.LastName.Length() > 80){
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Last name should be should be 80 characters or less.'));
            isValidationErrorOccured = true;
        }
        if(String.IsNotBlank(user.Phone)){
            
            user.phone = user.phone.replace('(', '');
            user.phone= user.phone.replace(')', '');
            user.phone = user.phone.replace('-', '');
            user.phone = user.phone.replace(' ', '');
            
            if(user.Phone.Length() != 10){
                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Phone number should be 10 digits.')); 
                isValidationErrorOccured = true;   
            }
            else{
                Pattern isnumbers = Pattern.Compile('^[0-9]+$');
                Matcher phoneMatch = isnumbers.matcher(user.phone);
                if(!phoneMatch.Matches()){
                    ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Phone number should have numeric characters only.')); 
                    isValidationErrorOccured = true;   
                }
            }
        }
        
        //--Once client side validation is executed, below script needs to follow on.--
        if(!isValidationErrorOccured){
            boolean isTimeZoneValid = false;
            
            isUserExist = validateSC_User(user);
            strSM_Id = validateSM(sm_Name);
            isTimeZoneValid = validateManagerTimeZone(selectedTimeZone, strSM_Id);
            
            if(isUserExist){
                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Either Email or Employee LDAP already exists.'));
            }
            else{
                if(String.IsNotBlank(strSM_Id)){ 
                    isStoreExist = validateStoreCode(storeCode);
                    
                    if(!isStoreExist){
                        ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Store code does not exist.'));
                    }
                    else{
                        if(!isTimeZoneValid){
                            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error,'Sales Consultant timezone must match manager timezone.'));
                        }
                        else{
                            isRepNumberExist = validateRepNumber(user.Repnum__c);
                            
                            if(isRepNumberExist){
                                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Rep Number already exists in Salesforce.'));
                            }
                            else{
                                if( bOnBoardSC && 
                                    !skills_Cabinet && !skills_Closet && !skills_Garage && !skills_Bath && 
                                    !skills_Gutters && !skills_Insulation && !skills_Roofing && !skills_Siding && !skills_StormProtection && !skills_Windows ){
                                    ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'At least one product must be assigned to sales consultant.'));
                                }
                                else{
                                    //-- Create a user & sales consultant records.--
                                    createSCAndUserRecord(user, strSM_Id, sm_Name, bOnBoardSC, selectedTimeZone);
                                }
                            }
                        }
                    }   
                }
                else{
                    ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'Selected Sales Manager is not active.'));
                }
            }
        }
        return null;
    }
    
     /**
      * @description       This method is will be called to create Sales Manager (Location) record.                          
      * @param             N/A
      * @return            PageReference
      * @throws            N/A
    */ 
    public PageReference finish(){
        User obj_Usr = new User();
        string newSM_ID = null;
        PageReference pageRef;
        if(bOnBoardSC){
            if(String.IsNotBlank(user.email)){
                List<CKSW_BASE__Resource__c> lstSc = [Select Id, Name from CKSW_BASE__Resource__c where CKSW_BASE__Email__c =: user.email limit 1];
                if(lstSc != null && lstSc.size() >0){
                    pageRef = new PageReference('/' + lstSc[0].id);
                    
                    //--Send email for newly created consultant.--
                    // sendEmailAlert('Sales Consultant', lstSc[0].Name, 'Activated');
                }
                else{
                    pageRef = new PageReference('/home/home.jsp');
                }
            }
            else{
                pageRef = new PageReference('/home/home.jsp');
            }
        }
        return pageRef;
    }
    
    /**
      * @description       This method is will be called to create USER & Sales Consultant records.                          
      * @param             N/A
      * @return            N/A
      * @throws            N/A
    */ 
    public void createSCAndUserRecord(User user, String strSM_Id, String sm_Name, Boolean bOnBoardSC, String selectedTimeZone){
        if(bOnBoardSC){
            User obj_Usr = new User();
            //--Inserting a user record for Sales Consultant record.--
            obj_Usr = insertSalesConsultant_User(user, selectedTimeZone, sm_Name);
            
            if(String.isNotBlank(obj_Usr.id)){
                //--Assign permission set to newly created user.--
                assignpermissionSet(obj_Usr);
            }
            //--Inserting a Sales Consultant record.--
            insertSalesConsultantRecord(obj_Usr.id, storeCode, strSM_Id, skills_Cabinet, skills_Closet, skills_Garage, skills_Bath, 
                                        skills_Gutters, skills_Insulation, skills_Roofing, skills_Siding, skills_StormProtection, skills_Windows);   

            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.CONFIRM, 'User and SC records created successfully. Thank you!'));
        }
    }
    
    /**
      * @description       This method is will be called when user clicks on cancel button. Once clicked, User will be redirected to Home page tab.                          
      * @param             N/A
      * @return            PageReference
      * @throws            N/A
    */ 
    public PageReference cancel(){
        PageReference pageRef;
        if(String.IsNotBlank(user.email)){
            List<CKSW_BASE__Resource__c> lstSc = [Select Id, Name from CKSW_BASE__Resource__c where CKSW_BASE__Email__c =: user.email LIMIT 1];
            if(lstSc != null && lstSc.size() >0){
                pageRef = new PageReference('/' + lstSc[0].id);
            }
            else{
                pageRef = new PageReference('/home/home.jsp');
            }
        }
        else{
            pageRef = new PageReference('/home/home.jsp');
        }
        pageRef.setRedirect(true);
        return pageRef;
    }

    /**
      * @description       This method is will be called when user clicks on next button. Once clicked, User will be redirected to either
      *                    OnboardUser page or de-Activate user page.(based on the checkbox selection on UI).
      * @param             N/A
      * @return            PageReference
      * @throws            N/A
    */
    public PageReference next(){
        
        if(bOnBoardSC && bOffBoardSC){
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'You cannot select more then one option at same time. Please select only one to move forward.'));
        } 
        else if(!bOffBoardSC || bOnBoardSC){
            return Page.TestOnboard;    
        }
        else if(bOffBoardSC ||  !bOnBoardSC){
            return Page.TestOffboard; 
        }
        return null;
    }
    
    /**
      * @description       This method is will be called when SM wants to terminate a sales consultant.                          
      * @param             N/A
      * @return            PageReference
      * @throws            N/A
    */ 
    public PageReference terminate(){
        Boolean IsUserDeActivated = false;
        boolean isAppointment = false;
        boolean isEmployeeAbsence = false;
        List<User> lstUsr = new List<User>();
        if(String.IsNotBlank(LDAP)){
            lstUsr =   [SELECT Id, IsActive FROM User WHERE Associate_Code__c =: LDAP AND IsActive =: TRUE LIMIT 1]; 
        }

        if(lstUsr.size() > 0){
        
            //-- Validate whether sales consultant has any assigned appointments or not.--
            isAppointment = validateSalesConsultant_Appointment(lstUsr[0].id);
            
            //--Validate whether sales consultant has any assigned employee absences or not.-- 
            isEmployeeAbsence = validateSalesConsultant_EmpAbsence(lstUsr[0].id);
            
            if(isAppointment){
                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error,'This sales consultant cannot be deactivated since it has some appointments with customers.'));
            }
            else{
                if(isEmployeeAbsence){
                    ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error,'This sales consultant cannot be deactivated since it has some future employee absence.'));
                }
                else{
                    //--DeActivate User record.--
                    IsUserDeActivated  = deActivateSalesConsultant_UserRecord(lstUsr[0]);  
                           
                    if(IsUserDeActivated){
                        ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.CONFIRM, 'This user does not have any appointments or employee absences. Thus the user is terminated successfully. Thank you!'));
                        //--Sales Consultant deActivated.--
                        deActivate_SalesConsultant(lstUsr[0].id);
                    }
                }
            }
        }
        else{
            ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'No active user found with provided LDAP.'));
        }
        return null;
    }
    
    /**
      * @description       This method is used to deactivate sales consultant user record.
      * @param             N/A
      * @return            N/A
      * @throws            N/A
    */
    public boolean deActivateSalesConsultant_UserRecord(User usr){
       boolean isDeActivated = false;
       if(usr!= null){
            usr.isActive = false;
            usr.Termination_Date__c = system.today();
            UPDATE usr; 
            isDeActivated = true;
        }    
        return isDeActivated;  
    } 
    
    /**
      * @description       This method is used to deactivate sales consultant record.                          
      * @param             N/A
      * @return            pageReference
      * @throws            N/A
    */
    @future
    public static void deActivate_SalesConsultant(string user_Id){
        CKSW_BASE__Resource__c salesCon = new CKSW_BASE__Resource__c();
        Boolean isResourceSkill_Deleted = false;
        Boolean isWorkingLocation_Deleted = false;
        Boolean isResourceCalender_Deleted = false;
        Boolean isBaseStore_Deleted = false;
        
        try{
            if(String.IsNotBlank(user_Id)){
                salesCon = [SELECT id, name FROM CKSW_BASE__Resource__c WHERE CKSW_BASE__User__c =: user_Id limit 1];
                if(salesCon != null){
                    isResourceSkill_Deleted = delete_ResourceSkills(salesCon);
                    if(isResourceSkill_Deleted){
                        isResourceCalender_Deleted = delete_ResourceCalender(salesCon);
                        if(isResourceCalender_Deleted){
                            isWorkingLocation_Deleted = delete_WorkingLocation(salesCon);
                            if(isWorkingLocation_Deleted){
                                isBaseStore_Deleted = delete_BaseStore(salesCon);
                            }
                        }
                    }
                    if(isBaseStore_Deleted){
                        salesCon.CKSW_BASE__Active__c = false;
                        UPDATE salesCon;
                        // sendEmailAlert('Sales Consultant', salesCon.Name, 'deActivated');
                    }
                }    
            }      
        }
        Catch(Exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant', 'deActivate_SalesConsultant');
        }       
    } 
    
    /**
      * @description       This method is used to delete ResourceSkills records associated to sales consultant record.                          
      * @param             CKSW_BASE__Resource__c salesCon
      * @return            boolean
      * @throws            N/A
    */
    public static boolean delete_ResourceSkills(CKSW_BASE__Resource__c salesCon){
        boolean isDeleted =  false;
        
        try{
            List<CKSW_BASE__Resource_Skill__c>  lstSR  = new list<CKSW_BASE__Resource_Skill__c>();
            lstSR = [SELECT id, name FROM CKSW_BASE__Resource_Skill__c WHERE CKSW_BASE__Resource__c =: salesCon.id LIMIT :(Limits.getLimitQueryRows()- Limits.getQueryRows())];
            if(lstSR.size()>0){
                DELETE lstSR;
                isDeleted =  true;
            }
            else if(lstSR.size() == 0){
                isDeleted =  true;
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant', 'delete_ResourceSkills');
        }
        return  isDeleted;
    }
    
    /**
      * @description       This method is used to delete Resource Calendar records associated to sales consultant record.
      * @param             CKSW_BASE__Resource__c salesCon
      * @return            boolean
      * @throws            N/A
    */
    public static boolean delete_ResourceCalender(CKSW_BASE__Resource__c salesCon){
        boolean isDeleted =  false;
        List<CKSW_BASE__Resource_Calendar__c> listRC = new list<CKSW_BASE__Resource_Calendar__c>();
        try{
            listRC = [SELECT id, name FROM CKSW_BASE__Resource_Calendar__c WHERE CKSW_BASE__Resource__c =: salesCon.id LIMIT :(Limits.getLimitQueryRows()- Limits.getQueryRows())];
            if(listRC.size()> 0 ){
               DELETE listRC;
               isDeleted =  true;
            }
            else if(listRC.size() == 0){
                isDeleted =  true;
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
             ExceptionHandling.addException(ex,'ManageSalesConsultant', 'delete_ResourceCalender');
        }
        return  isDeleted;
    }
    
    /**
      * @description       This method is used to delete WorkingLocation records associated to sales consultant record.                          
      * @param             CKSW_BASE__Resource__c salesCon
      * @return            boolean
      * @throws            N/A
    */
    public static boolean delete_WorkingLocation(CKSW_BASE__Resource__c salesCon){
        boolean isDeleted = false;
        List<CKSW_BASE__Working_Location__c> lstRC = new list<CKSW_BASE__Working_Location__c>();
        try{
            lstRC = [SELECT Id, Name FROM CKSW_BASE__Working_Location__c WHERE CKSW_BASE__Resource__c =: salesCon.id LIMIT :(Limits.getLimitQueryRows() - Limits.getQueryRows())];
            if(lstRC.size() > 0){
               DELETE lstRC;
               isDeleted = true;
            }
            else if(lstRC.size() == 0){
                isDeleted = true;
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
             ExceptionHandling.addException(ex,'ManageSalesConsultant', 'delete_WorkingLocation');
        }
        return isDeleted;
    }

    /**
      * @description       This method is used to delete BaseStore from the sales consultant record.                          
      * @param             CKSW_BASE__Resource__c salesCon
      * @return            boolean
      * @throws            N/A
    */
    public static boolean delete_BaseStore(CKSW_BASE__Resource__c salesCon){
        boolean isDeleted = false;

        try{
            salesCon.Base_Store__c = NULL;
            system.Debug('*******salesCon.Base_Store__c*****' + salesCon.Base_Store__c);            
            isDeleted = true;
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
             ExceptionHandling.addException(ex,'ManageSalesConsultant', 'delete_BaseStore');
        }
        return isDeleted;
    }
    
    /**
      * @description       This method is used to insert a user record for Sales consultant profile.                          
      * @param             N/A
      * @return            N/A
      * @throws            N/A
    */
    public static user insertSalesConsultant_User(user usr, String selectedTimeZone, String sm_Name){
        User u = new User();
        List<UserRole> lstUserRole = new List<UserRole>();
        CKSW_BASE__Location__c mgt = new CKSW_BASE__Location__c();
        String strUserRoleid  = null;
        String strMgtRoleId = null;
        String strProfileId = null;
        strProfileId = [SELECT Id FROM Profile WHERE name =: 'THD Sales' LIMIT 1].id;
        
        mgt = [SELECT id, ownerid from CKSW_BASE__Location__c where Name =: sm_Name];
        if(String.IsNotBlank(mgt.ownerid)){
            for(User us : [SELECT Id, userroleid FROM User WHERE Id =: mgt.ownerid LIMIT 1]){
                strMgtRoleId = us.userroleid;
            }
            if(String.IsNotBlank(strMgtRoleId)){
                lstUserRole = [SELECT Id, name from UserRole where ParentRoleId =: strMgtRoleId ];
                    if(lstUserRole.size() > 0){
                        strUserRoleId = lstUserRole[0].Id; 
                    }
            }
        }
        u.emailencodingkey='UTF-8';
        u.timezonesidkey = selectedTimeZone;
        u.languagelocalekey = 'en_US';
        u.localesidkey = 'en_US';
        if(String.isNotBlank(strUserRoleid)){
            u.UserRoleId = strUserRoleid;
        }
        u.ProfileId = strProfileId;
        u.title = 'Sales Consultant';
        u.isActive = true;
        u.email = usr.email;
        
        u.username = usr.email + '.' + label.UsernamePostFix;
        u.firstname = usr.firstname;
        u.lastname = usr.lastname;
        u.Associate_Code__c = usr.Associate_Code__c;
        u.Hire_Date__c = usr.Hire_Date__c;
        u.Repnum__c = usr.Repnum__c;
        u.Phone = usr.Phone;
        u.managerid = mgt.ownerid;
        u.USERPERMISSIONSKNOWLEDGEUSER = true;
        
        u.communityNickname = u.LastName.substring(0,2) + '_'+ Math.random();
        u.alias = string.valueof(u.FirstName.substring(0,1) + u.LastName.substring(0,1) + String.Valueof(Math.random()).substring(0,3) );   

        Insert u;
        system.debug('*******insertSalesConsultant_User2*****' + u);
        return u;
    } 
    
    /**
      * @description       This method is used to insert a Sales Consultant record.
      * @param             user info
      * @return            N/A
      * @throws            N/A
    */
    @future
    public static void insertSalesConsultantRecord(String userId, String strStoreCode, String strSM_Id, 
                                                   boolean skills_Cabinet, boolean skills_Closet, boolean skills_Garage, boolean skills_Bath,
                                                   boolean skills_Gutters, boolean skills_Insulation, boolean skills_Roofing, boolean skills_Siding, boolean skills_StormProtection, boolean skills_Windows){
        CKSW_BASE__Resource__c objSalesCon = new CKSW_BASE__Resource__c();
        Store__c objStore = new Store__c();
        
        if(String.IsNotBlank(strSM_Id)){
            user u = [select Name, id, Associate_Code__c, Managerid, Repnum__c from user WHERE id= : userId];
            objStore = [select id, Name, Store_Code__c, Sales_Manager__c, Geolocation__latitude__s, Geolocation__longitude__s from Store__c where Store_Code__c =: strStoreCode];
            objSalesCon.Name = u.Name;
            objSalesCon.User_LDAP__c =  u.Associate_Code__c;
            objSalesCon.ownerid = u.id;
            objSalesCon.CKSW_BASE__User__c = u.id;
            objSalesCon.CKSW_BASE__Active__c = true;
            objSalesCon.User_LDAP__c = u.Associate_Code__c;
            objSalesCon.Resource_Code__c = u.Repnum__c;
            objSalesCon.CKSW_BASE__Location__c = strSM_Id;
            
            //-- Assign tool text on sales consultant record.--
            objSalesCon.CKSW_BASE__Tooltip_Text__c = createTooltipText(skills_Cabinet, skills_Closet, skills_Garage, skills_Bath, skills_Gutters, skills_Insulation, skills_Roofing, skills_Siding, skills_StormProtection, skills_Windows);
            
            if(objStore!= null){
                objSalesCon.CKSW_BASE__Gantt_Label__c = strStoreCode;
                objSalesCon.Base_Store__c = objStore.id;
                objSalesCon.CKSW_BASE__Homebase__longitude__s = objStore.Geolocation__longitude__s;
                objSalesCon.CKSW_BASE__Homebase__latitude__s = objStore.Geolocation__latitude__s;
            }
        }
        system.debug('*******insertSalesConsultantRecord*****objSalesCon ' + objSalesCon);
        insert objSalesCon;
        
        if(objSalesCon != null && String.IsNotBlank(objSalesCon.id)){
        
            //--Assign Skill sets to sales consultants.--
            assignSkillsSet(objSalesCon, skills_Cabinet, skills_Closet, skills_Garage, skills_Bath, skills_Gutters, skills_Insulation, skills_Roofing, skills_Siding, skills_StormProtection, skills_Windows);
            
            //--Assign resource calander to sales consultants.--
            assignResourceCalendar(objSalesCon);
            
            //-- Assign Working location child record to sales consultant.--
            assignWorkingLocation(objSalesCon.id, strSM_Id);
        }
        
    }
    
    /**
        * @description       This is an internal method used to insert a permissionSet record against a newly created user records.                          
        * @param             List<user> lstUsr
        * @return            N/A
        * @throws            N/A
    */
    public static void assignPermissionSet(user usr){
        try{
            List<PermissionSetAssignment> lstPermissionSetAssignment = new List<PermissionSetAssignment>();
            map<string,permissionSet> mapPS = new map<string,permissionSet>();
            
            //--Retrieving all permission sets on a map binded with key as permission set name & value as object..
            for (permissionSet ps : [SELECT id, name, label, description from permissionSet LIMIT :(Limits.getLimitQueryRows()- Limits.getQueryRows())]){
                mapPS.put(ps.label, PS);
            }
            
            //--Assigning permissionSet id in PermissionSetAssignment object.-- 
            PermissionSetAssignment psa = new PermissionSetAssignment(); 
            psa.PermissionSetId = mapPS.get('THD HDI Field Service Sales Consultant').id;
            
            psa.AssigneeId = usr.id;
            lstPermissionSetAssignment.add(psa);
            //-- Inserting list of PermissionSetAssignment object to enable SC with required permissions. 
            insert lstPermissionSetAssignment;
        }
        catch(exception ex){
             //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
             ExceptionHandling.addException(ex,'ManageSalesConsultant', 'assignPermissionSet');
        }
    }
    
    /**
        * @description       This is an internal method used to insert resource skills to newly inserted sales consultant.                          
        * @param             CKSW_BASE__Resource__c objSalesCon
        * @return            N/A
        * @throws            N/A
    */
    public static void assignSkillsSet(CKSW_BASE__Resource__c objSalesCon, 
                                       boolean skills_Cabinet, boolean skills_Closet, boolean skills_Garage, boolean skills_Bath,
                                       boolean skills_Gutters, boolean skills_Insulation, boolean skills_Roofing, boolean skills_Siding, boolean skills_StormProtection, boolean skills_Windows){
        if(objSalesCon != null){
            try{
                list<CKSW_BASE__Resource_Skill__c> lstrs = new List<CKSW_BASE__Resource_Skill__c>();
                Map<String,CKSW_BASE__Skill__c> mapSkills = new Map<String,CKSW_BASE__Skill__c>();
                List<CKSW_BASE__Skill__c> lstSkills = [select id , name FROM CKSW_BASE__Skill__c]; 
                
                for(CKSW_BASE__Skill__c skills : lstSkills){
                    mapSkills.put(skills.name, skills);
                } 
                
                if(skills_Cabinet){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Cabinet Refacing').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                    
                    CKSW_BASE__Resource_Skill__c rs2 = new CKSW_BASE__Resource_Skill__c();
                    rs2.CKSW_BASE__Skill__c =  mapSkills.get('Countertops').id;
                    rs2.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs2);
                    
                    CKSW_BASE__Resource_Skill__c rs3 = new CKSW_BASE__Resource_Skill__c();
                    rs3.CKSW_BASE__Skill__c =  mapSkills.get('Backsplash').id;
                    rs3.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs3);
                }
                
                if(skills_Closet){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Closet Organization').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_Garage){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Garage Organization').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_Bath){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Tub & Shower Liners').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_Gutters){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Gutters/Leaf Protection').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }                
                
                if(skills_Insulation){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Home Insulation').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_Roofing){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Roofing').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_Siding){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Siding').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_StormProtection){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Storm Protection').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }
                
                if(skills_Windows){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Windows').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                }

                if(lstrs.size() > 0){
                    CKSW_BASE__Resource_Skill__c rs1 = new CKSW_BASE__Resource_Skill__c();
                    rs1.CKSW_BASE__Skill__c =  mapSkills.get('Selling').id;
                    rs1.CKSW_BASE__Resource__c = objSalesCon.id;
                    lstrs.add(rs1);
                    Insert lstrs;
                }
            }
            catch(exception ex){
                //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
                ExceptionHandling.addException(ex,'ManageSalesConsultant', 'assignSkillsSet');
            }
        }    
    }
    
    /**
        * @description       This is an internal method used to validate unique username & LDAP.
        * @param             string strUserName
        * @param             string strLDAP
        * @return            boolean
        * @throws            N/A
    */
    public static boolean validateSC_User(User usr){
        boolean bIsUnique = false;
        list<User> lstUsr = new List<User>();
        lstUsr = [select id from user where email =: usr.email or Associate_Code__c =: usr.Associate_Code__c LIMIT 1];
        if(lstUsr.size() > 0){
            bIsUnique = true;
        }
        return bIsUnique;
    }
    
    /**
        * @description       This is an internal method used to validate the store code exists.
        * @param             string strManagerLDAP
        * @return            boolean
        * @throws            N/A
    */
    public static boolean validateStoreCode(string strStoreCode){
        boolean bExists = false;
        List<Store__c> lstStore = new List<Store__c>();
        lstStore = [select id from Store__c where Store_Code__c =: strStoreCode LIMIT 1];
        if(lstStore.size() > 0){
            bExists = true;
        }
        return bExists;
    }
    
    /**
        * @description       This is an internal method used to validate rep number in user object.
        * @param             string strRepNum
        * @return            boolean
        * @throws            N/A
    */
    public static boolean validateRepNumber(string strRepNum){
        boolean bIsValid = false;
        List<User> lstStore = new List<User>();
        if(String.IsNotBlank(strRepNum)){
            lstStore = [select id from User where Repnum__c =: strRepNum LIMIT 1];
            if(lstStore.size() > 0){
                bIsValid = true;
            }
        }
        return bIsValid;
    }
    
    /**
        * @description       This is an internal method used to assign the resource calender to the sales consultant as a related list record.
        * @param             string strRepNum
        * @return            void
        * @throws            N/A
    */
    public static void assignResourceCalendar(CKSW_BASE__Resource__c salesCon){
        try{
            boolean flag = false;
            CKSW_BASE__Resource_Calendar__c  rc = new CKSW_BASE__Resource_Calendar__c (); 
            for( CKSW_BASE__Calendar__c cal : [SELECT Id, name FROM  CKSW_BASE__Calendar__c WHERE name =: 'Base Calendar' LIMIT 1]){
                rc.CKSW_BASE__Resource__c =  salesCon.Id;
                rc.CKSW_BASE__Calendar__c = cal.Id;
                flag = true;
            }
            if(flag){
                insert rc;
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant', 'assignResourceCalendar');
        }
    }

    /**
        * @description       This is an internal method used to assign working location to sales consultant as a related list record.
        * @param             string salesConId
        * @param             string salesMgrId
        * @return            void
        * @throws            N/A
    */
    public static void assignWorkingLocation(String salesConId, String salesMgrId){
        try{
            if(String.IsNotBlank(salesConId) && String.IsNotBlank(salesMgrId)){
                CKSW_BASE__Working_Location__c  wl = new CKSW_BASE__Working_Location__c(); 
                wl.CKSW_BASE__Resource__c = salesConId;
                wl.CKSW_BASE__Location__c = salesMgrId;
                
                Insert wl;
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant','assignWorkingLocation');
        }
    }
    
    /**
        * @description       This is an internal method used to create the tooltip text field value for the sales consultant.
        * @param             boolean skills_Cabinet
        * @param             boolean skills_Closet
        * @param             boolean skills_Garage
        * @param             boolean skills_Bath
        * @param             boolean skills_Gutters
        * @param             boolean skills_Insulation
        * @param             boolean skills_Roofing
        * @param             boolean skills_Siding
        * @param             boolean skills_StormProtection
        * @param             boolean skills_Windows
        * @return            String
        * @throws            N/A
    */
    public static String createTooltipText(boolean skills_Cabinet, boolean skills_Closet, boolean skills_Garage, boolean skills_Bath,
                                           boolean skills_Gutters, boolean skills_Insulation, boolean skills_Roofing, boolean skills_Siding, boolean skills_StormProtection, boolean skills_Windows){
        String strToolTip = '';
        try{
            if(skills_Cabinet){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip = 'Kitchen';
            }
            if(skills_Closet){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'Closet';
            }
            if(skills_Garage){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'Garage';
            }
            if(skills_Bath){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'Bath';
            }
            if(skills_Gutters){
                strToolTip = 'GUT';
            }
            if(skills_Insulation){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'AI';
            }
            if(skills_Roofing){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'ROF';
            }
            if(skills_Siding){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'SID';
            }
            if(skills_StormProtection){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'STM';
            }
            if(skills_Windows){
                if(String.isNotBlank(strToolTip)){
                    strToolTip += ', ';
                }
                strToolTip += 'WIN';
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant', 'assignToolTiptext');
        }
        return strToolTip;
    }
    
    /**
        * @description       This is an internal method used to determine whether SC has any assigned appointments or not.
        * @param             string salesConId
        * @param             string salesMgrId
        * @return            boolean
        * @throws            N/A
    */
    public static boolean validateSalesConsultant_Appointment(String strUserid){
        boolean bHasAppointments = false;
        List<CKSW_BASE__Service__c> lstApt = new List<CKSW_BASE__Service__c>(); 
        String salesConId;
        List<CKSW_BASE__Service_Type__c> lstServiceType = new List<CKSW_BASE__Service_Type__c>();
        
        lstServiceType = [SELECT Id from CKSW_BASE__Service_Type__c where Name like 'HDMS%'];
        
        try{
            for(CKSW_BASE__Resource__c sc : [SELECT Id, name FROM CKSW_BASE__Resource__c WHERE CKSW_BASE__User__c =: strUserid limit 1]){
                salesConId = sc.Id;
            }
       
            if(String.IsNotBlank(salesConId)){
                lstApt = [select Id from CKSW_BASE__Service__c 
                            WHERE CKSW_BASE__Resource__c =: salesConId 
                            AND CKSW_BASE__Start__c >= TODAY
                            AND CKSW_BASE__Status__c != 'Dispatched' AND CKSW_BASE__Status__c != 'Traveling' AND CKSW_BASE__Status__c != 'Check'
                            AND CKSW_BASE__Service_Type__c NOT IN : lstServiceType
                            LIMIT :(Limits.getLimitQueryRows()- Limits.getQueryRows())];
                if(lstApt.size() > 0){
                    bHasAppointments = true;
                }
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant', 'assignWorkingLocation');
        }
        return bHasAppointments;
    }
    
    /**
        * @description       This is an internal method used to determine whether SC has any assigned employee absences or not.                             
        * @param             string strUserid
        * @return            boolean
        * @throws            N/A
    */
    public static boolean validateSalesConsultant_EmpAbsence(String strUserid){
        boolean bHasAbsences = false;
        List<CKSW_BASE__Employee_Absence__c> lstEmpAbsence = new List<CKSW_BASE__Employee_Absence__c>(); 
        String salesConId;
        system.debug('*******strUserid********'+strUserid);
        try{
            for(CKSW_BASE__Resource__c sc : [SELECT Id, name FROM CKSW_BASE__Resource__c WHERE CKSW_BASE__User__c =: strUserid limit 1]){
                salesConId = sc.Id;
            }
       
            if(String.IsNotBlank(salesConId)){
                lstEmpAbsence = [SELECT Id from CKSW_BASE__Employee_Absence__c where CKSW_BASE__Resource__c =: salesConId AND CKSW_BASE__Date__c >= today LIMIT :(Limits.getLimitQueryRows()- Limits.getQueryRows())];
                system.debug('*******lstEmpAbsence ********'+lstEmpAbsence );
                if(lstEmpAbsence.size() > 0){
                    bHasAbsences = true;
                }
            }
        }
        catch(exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant', 'validateSalesConsultant_EmpAbsence');
        }
        return bHasAbsences;
    }
    
    /**
        * @description       This is an method used to get user details.
        * @param             Sobject object_name
        * @param             String field_name
        * @return            void
        * @throws            N/A
    */
    public void userDetails() {
        if(String.IsNotBlank(LDAP)){
            lstUser = [Select Id, name, firstname , Associate_Code__c, IsActive, Email, Hire_Date__c, Repnum__c, Phone, managerid from USER where  Associate_Code__c =:  LDAP AND IsActive =: true Limit 1];
            if(lstUser.size() == 0){
                ApexPages.AddMessage(new ApexPages.Message(ApexPages.Severity.Error, 'No active user found with provided LDAP'));
            }
        }
    }
    
    /**
        * @description       This is an internal method used to validate SM.                           
        * @param             string strSM_Name
        * @return            string strSMid
        * @throws            N/A
    */
    public static string validateSM(string strSM_Name){
        String strSM_Id = null;
        if(String.IsNotBlank(strSM_Name)){
            for(CKSW_BASE__Location__c cbl : [SELECT Id from CKSW_BASE__Location__c where Name =: strSM_Name LIMIT 1]){
                strSM_Id = cbl.Id;
            }
        }
        return strSM_Id;
    }
        
    /**
        * @description       This is an internal method used to customize timezones in a picklist.                           
        * @param             N/A
        * @return            List<SelectOption> timeZoneOption
        * @throws            N/A
    */    
    public List<SelectOption> getTimeZoneOptions() {
        List<SelectOption> timeZoneOption= new List<SelectOption>();
        timeZoneOption.add(new SelectOption('America/New_York','Eastern'));
        timeZoneOption.add(new SelectOption('America/Chicago','Central'));
        timeZoneOption.add(new SelectOption('America/Denver','Mountain'));
        timeZoneOption.add(new SelectOption('America/Phoenix','Phoenix'));
        timeZoneOption.add(new SelectOption('America/Los_Angeles','Pacific'));
        
        return timeZoneOption;
    }
     
       /**
        * @description       This is an internal method used to send email.                           
        * @param             N/A
        * @return            N/A
        * @throws            N/A

    public static void sendEmailAlert(String UserType, String Name, String event){
        try{
            List<String> lstToAddress = new List<String>();
            //--Creating Subject.--
            String subject = UserType + ' ' + event;
            
            //--Creating Body of email.--
            String body = 'A new ' + UserType + ', ' + Name + ' ' + ', has been successfully ' + Event + ' in Production. Attached are the details to create this user in the LL environments.';
            
            //--Senders Email.--
            List<OrgWideEmailAddress> lstOwea = [select Id from OrgWideEmailAddress where Address = 'homeservices_sfdc_support@homedepot.com' Limit 1];
            
            //--To Email Address.--
            for(OnBoardOffBoardEmails__c  onOffB : [Select name, ToEmailAddress__c from OnBoardOffBoardEmails__c LIMIT 10]){
                lstToAddress.add(onOffB.ToEmailAddress__c);
            }
            system.debug('*****lstToAddress******'+lstToAddress);
            list<String> lstme = new List<String>{'vivian_j_viverito@homedepot.com'};
            
            EmailUtility.composeEmail(null, body, subject, lstme, lstOwea[0].id);
            //composeEmail(List<Messaging.EmailFileAttachment> lstAttach, String body, String subject, List<String> lstToAddress, String strOrgWideEmailAddressId){
            
        }
        Catch(Exception ex){
            //-- Creating a log on ErrorLog custom object when ever there is an error in apex. 
            ExceptionHandling.addException(ex,'ManageSalesConsultant','insertSalesManagerRecord');
        }
    }
    */

    /**
        * @description       This is an internal method to decline special characters in the input parameter.                           
        * @param             String str
        * @return            boolean alphaNumMatch.Matches()
        * @throws            N/A
    */
    public boolean validateAlphaNumeric(String str){
        system.debug('******str******' + str);
        Pattern isAlphaNumeric = Pattern.Compile('^[a-zA-Z0-9]*$');
        Matcher alphaNumMatch = isAlphaNumeric.matcher(str);
        system.debug('******alphaNumMatch.Matches()******' + alphaNumMatch.Matches());
        return alphaNumMatch.Matches();
    }
    
    /**
        * @description       This is an internal method to validate manager's time zone is the same as selected timezone for the sales consultant.                           
        * @param             String strTimeZone
        * @return            flag
        * @throws            N/A
    */
    public boolean validateManagerTimeZone(String strTimeZone, String strSmId){
            boolean flag = false;
            CKSW_BASE__Location__c sm_TimeZ = new CKSW_BASE__Location__c();
            
            sm_TimeZ = [SELECT Id, CKSW_BASE__Time_Zone__c from CKSW_BASE__Location__c where Id =: strSmId];
            
            if(strTimeZone.equals(sm_TimeZ.CKSW_BASE__Time_Zone__c)){
                flag = true;
            }
            return flag;
    }
}